﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VideojuegosApp.Models;

namespace Videojuegos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VideojuegosController : ControllerBase
    {
        private readonly VideojuegosContext _context;

        public VideojuegosController(VideojuegosContext context)
        {
            _context = context;
        }

        // Método para obtener todos los videojuegos y su info de la base de datos junto con el nombre de la categoria
        // GET: api/Videojuegoes 
        [HttpGet]
        [Route("ListaJuegos")]
        public async Task<ActionResult<IEnumerable<Videojuego>>> GetVideojuegos()
        {
            var videojuegos = await _context.Videojuegos
                .Include(j => j.Categoria)
                .Select(j => new
                {
                    j.Nombre,
                    j.Descripcion,
                    j.Precio,
                    j.ModoJuego,
                    j.ImageUrl,
                    Categoria = j.Categoria.Nombre,
                }).ToListAsync();

            return Ok(videojuegos);
        }

        // Metodo para buscar videojuegos por su nombre
        // GET: api/Videojuegos/NombreJuego
        [HttpGet]
        [Route("NombreJuego")]
        public async Task<ActionResult<IEnumerable<object>>> GetJuegoNombre(string nombre)
        {
            var videojuegos = await _context.Videojuegos
                .Include(j => j.Categoria)
                .Where(j => j.Nombre.Contains(nombre))
                .Select(j => new
                {
                    j.Nombre,
                    j.Descripcion,
                    j.Precio,
                    j.ModoJuego,
                    j.ImageUrl,
                    Categoria = j.Categoria.Nombre,
                }).ToListAsync();

            if (videojuegos == null || !videojuegos.Any())
            {
                return NotFound();
            }

            return Ok(videojuegos);
        }

        // Metodo para obtener las categorias de la base de datos
        // GET: api/Videojuegos/Categorias
        [HttpGet]
        [Route("Categorias")]
        public async Task<ActionResult<IEnumerable<Categoria>>> GetCategorias()
        {
            var categorias = await _context.Categorias.ToListAsync();

            if (categorias == null)
            {
                return NotFound();
            }

            return categorias;
        }

        // Metodo para obtener los videojuegos de una categoria
        // GET: api/Videojuegos/CategoriaJuego 
        [HttpGet]
        [Route("CategoriaJuego")]
        public async Task<ActionResult<IEnumerable<Videojuego>>> GetJuegoCategoria(int categoriaId)
        {
            var videojuego = await _context.Videojuegos.Where(j => j.CategoriaId == categoriaId).ToListAsync();

            if (videojuego == null)
            {
                return NotFound();
            }

            return videojuego;
        }
    }
}

