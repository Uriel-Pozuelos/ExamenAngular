﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace VideojuegosApp.Models
{
    public class Videojuego
    {
        [Key]
        public int VideojuegoId { get; set; }
        [Required]
        [MaxLength(100)]
        public string? Nombre { get; set; }
        [MaxLength(255)]
        public string? Descripcion { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal Precio { get; set; }
        [MaxLength(100)]
        public string? ModoJuego { get; set; }
        public int CategoriaId { get; set; }
        [MaxLength(255)]
        public string? ImageUrl { get; set; }

        [ForeignKey("CategoriaId")]
        public virtual Categoria? Categoria { get; set; }
    }
}
