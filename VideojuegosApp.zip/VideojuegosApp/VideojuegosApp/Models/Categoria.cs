﻿using System.ComponentModel.DataAnnotations;

namespace VideojuegosApp.Models
{
    public class Categoria
    {
        [Key]
        public int CategoriaId { get; set; }
        [Required]
        [MaxLength(100)]
        public string Nombre { get; set; }
        [MaxLength(255)]
        public string Descripcion { get; set; }

        public virtual ICollection<Videojuego> Videojuegos { get; set; }
    }
}
