﻿using Microsoft.EntityFrameworkCore;

namespace VideojuegosApp.Models
{
    public class VideojuegosContext : DbContext
    {
        public VideojuegosContext() { }
        public VideojuegosContext(DbContextOptions<VideojuegosContext> options): base(options)
        {
        }

        public DbSet<Videojuego> Videojuegos { get; set; }
        public DbSet<Categoria> Categorias { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Videojuego>()
                .Property(v => v.Precio)
                .HasColumnType("decimal(10,2)");
        }
    }
}
